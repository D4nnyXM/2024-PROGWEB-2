import Botao from "./components/Botao/Botao";
import Texto from "./components/Texto/Texto";
import Input from "./components/Input/input";

import'./App.css'
//export default function App() {} assim depois tem que por mais detalhes
function App() {
  return (
    
    <div className='card'>
      
        <Texto />
        <Input />
        <Texto />
        <Input />
        <Texto />
        <Botao />
        



      
     

    </div>
    


  )

}
export default App; //ou pode ser no final export default App; assim facilita mais 
/* //<div> Minha primeira pagina <br/>
    <Botao />
    </div>*/ 