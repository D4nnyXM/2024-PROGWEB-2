import'./stylo.css'


export default function Botao(){

    const evento = () => {
        alert("Meu pastel é mais barato")
    } //criando uma constante que sabe fazer alguma coisa
    
    return (        
        <button className='botao' onClick={evento}>Salvar</button>

    )
}