import'./style.css'



export default function Input(){// havera exemplo que nao tera export default, no caso o default
               // crie sempre a funçao com letra maiuscula         
        
    return ( // retunr nao é funçao é o que retorna  é o que precisa ser visto      

        <input type="text" className='entrada' placeholder='Digite seu email' />

    )
}
//sempre tera essas caracteristicas
// import css
// export 
// retunr