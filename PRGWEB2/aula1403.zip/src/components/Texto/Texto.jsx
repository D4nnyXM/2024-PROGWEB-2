import'./style.css'


export default function Texto (){

   
    return (      

        <label className='texto'> Exemplo</label>  //label é um textinho    class=""esse é do html, class='' assim é para o react
      

    )
}